The following files are provided as templates for importing into the PixelCons Advanced creator:
- 10x10.png
- 5x5.png
- single.png

File importing follows the following rules:
1) Empty cells in a grid will be ignored by the importer
2) All colors must closely match one of the common 16 colors (except for the grid border)
3) Grid border is not necessary if only uploading one PixelCon
4) Images can be scaled up as long as the grid proportions are maintained
5) Only PNG files can be imported
